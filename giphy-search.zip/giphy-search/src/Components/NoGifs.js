import React from 'react';

const NoGifs = () => (
    <p style={{color: 'white'}}>Nothing matches your search</p>
);

export default NoGifs;